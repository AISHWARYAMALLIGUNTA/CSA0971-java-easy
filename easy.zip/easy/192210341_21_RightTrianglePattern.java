class R192210341
{
	public static void main(String arg[])
	{
		int rows=3,i,j;
		for(i=0;i<rows;i++)
		{
	      for(j=0;j<=i;j++)
		{
			System.out.print("% ");
		}
		      System.out.println();
		}
	}
}
	
		