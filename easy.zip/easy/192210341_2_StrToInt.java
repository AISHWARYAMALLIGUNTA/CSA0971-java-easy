class StrToInt{
    public static void main(String arg[]) {
        String inputString = "1234";  
        int outputInteger = Integer.parseInt(inputString);
        System.out.println("Output Integer: " + outputInteger);
    }
}
