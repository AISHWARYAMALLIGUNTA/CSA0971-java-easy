import java.util.Scanner;
class user_Name{
    public static void main(String[]args){
        Scanner in=new Scanner(System.in);
        System.out.println("enter the user name: ");
        String str1=in.nextLine();
        System.out.println("Reenter the user name: ");
        String str2=in.nextLine();
        if(str1.equals(str2)){
            System.out.println("User name is valid");
        }
        else{
                System.out.println("User name is not valid");
            }
            }
        }
