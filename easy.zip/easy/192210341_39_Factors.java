class Factors
{
	public static void main(String arg[])
	{
		int n,i;
		n=6;
		for(i=1;i<=n;i++)
		{
			if(n%i==0)
			{
			 System.out.println(i);
			}
		}
	}
}