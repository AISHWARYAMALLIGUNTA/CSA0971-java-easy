class Factorial
{
	public static void main(String arg[])
	{
		int i,fact;
		fact=1;
		for(i=1;i<=5;i++)
		{
			fact=fact*i;
		}
			System.out.println(fact);
	}
}