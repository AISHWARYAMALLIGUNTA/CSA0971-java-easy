class ATM{
public static void main(String arg[]){
int n1=500,d1=4,n2=100,d2=20,n3=200,d3=32,n4=2000,d4=1; 
int Total=(n1*d1)+(n2*d2)+(n3*d3)+(n4*d4); 
System.out.print("Total Available Balance in ATM: "+Total); 
}
}
